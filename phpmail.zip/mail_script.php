<?php


if (isset($_POST['submit'])) {

    require 'phpmailer/PHPMailerAutoload.php';

    $email = "info@jaisinternational.com";
    $password = "jaisinternational";

    $to_id = "uit.mohsin95@gmail.com";

    $subject = "Customer Query Jais international";

    $csname = "\n Customer Name :- " . $_POST['username'];

    $csname_l = "\n Last Name :- " . $_POST['username_l'];

    $csemail = "\n Customer Email :- " . $_POST['user_email'];

    $csphone = "\n Customer Phone :- " . $_POST['user_contact'];


    $csMessage = "\n Customer Message :- " . $_POST['user_message'];



    $message = $csname . " " . $csemail . " " . $csphone .  " " . $csMessage;

    $mail = new PHPMailer;


    $mail->Host = 'mail.jaisinternational.com';

    $mail->Port = 465;

    $mail->SMTPSecure = 'ssl';

    $mail->SMTPAuth = true;

    $mail->Username = $email;

    $mail->Password = $password;

    $mail->setFrom($email, 'Jais International Client ');

    $mail->addReplyTo($email, $email);

    $mail->Subject = $subject;

    $mail->msgHTML($message);

    $mail->addAddress($to_id);



    if (!$mail->send()) {

        $error = "Mailer Error: " . $mail->ErrorInfo;

        echo "<script type='text/javascript'>alert('Not Sent')</script>";
        echo "<script>window.location.assign('http://www.jaisinternational.com/contacts.php')</script>";

    } else {


        echo "<script type='text/javascript'>alert('Sent Successfully')</script>";
        echo "<script>window.location.assign('http://www.jaisinternational.com/contacts.php')</script>";

    }
}



?>