<!DOCTYPE html>
<html class="wide wow-animation smoothscroll scrollTo" lang="en">

<!-- Mirrored from livedemo00.template-help.com/wt_61187/our-history.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Aug 2019 12:12:41 GMT -->
<head>
    <!-- Site Title-->
    <title>About Us</title>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport"
          content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="icon" href="http://static.livedemo00.template-help.com/wt_61187/images/favicon.ico" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css"
          href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,700%7CLato:400">
    <link rel="stylesheet" href="wt_61187/css/style.css">
    <!--[if lt IE 10]>
    <div style="background: #212121; padding: 10px 0; box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3); clear: both; text-align:center; position: relative; z-index:1;">
        <a href="http://windows.microsoft.com/en-US/internet-explorer/"><img
                src="images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820"
                alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a>
    </div>
    <script src="js/html5shiv.min.js"></script>
    <![endif]-->
</head>
<body>
<!-- Page-->
<div class="page text-center">
    <!-- Page Head-->
    <header class="page-head slider-menu-position">
        <!-- RD Navbar Transparent-->
        <?php include "bar.php"; ?>
        <!-- Modern Breadcrumbs-->
        <section
                class="section parallax-container section-height-800 breadcrumb-modern context-dark bg-teal-blue text-lg-left"
                data-parallax-img="images/backgrounds/travel-2.jpg">
            <div class="parallax-content">
                <div class="shell section-30 section-md-top-125 section-lg-top-210">
                    <div class="veil reveal-md-block">
                        <h1 class="text-bold">About Us</h1>
                    </div>
                    <ul class="list-inline list-inline-icon list-inline-icon-type-1 list-inline-icon-extra-small list-inline-icon-white p offset-md-top-30 offset-md-top-40 offset-lg-top-125">
                        <li><a class="text-white" href="index.php" style="font-size: 22px">Home</a></li>
                        <li><a class="text-white" href="our-history.php" style="font-size: 22px">About Us</a></li>
                        <!-- <li>Services
                        </li> -->
                    </ul>
                </div>
            </div>
        </section>
    </header>

    <!-- Page Contents-->
    <main class="page-content">
        <!-- A Few Words About Us-->
        <section class=" section-md-111 text-left">
            <div class="shell">
                <div class="range range-xs-center">
                    <div class="cell-sm-8 cell-md-12">
                        <div class="inset-lg-right-20">
                            <h2 class="text-bold text-center text-md-left">A Few Words About Us</h2>
                            <hr class="divider hr-md-left-0 bg-primary">
                            <div class="offset-top-30 offset-md-top-60">
                                <p>Founded by two fellow mountain-climbers Joseph Watson and Jim Harrison, this travel
                                    agency has always focused on encompassing the best of what winter resorts can offer
                                    worldwide.</p>

                                <div class="offset-top-10">
                                    <p>Across the globe, we’ve selected hundreds of best skiing & snowboarding resorts,
                                        any of which will ensure a perfectly fresh winter holiday experience for
                                        you.</p>
                                </div>
                                <div class="offset-top-10">
                                    <p>Since 2004 we’ve helped thousands of travelers enjoy their vacation time on ski
                                        resorts across all 5 continents!</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- Our History-->

        <!-- Happy Travelers-->

        <section class="">
            <div class="shell">
                <h2 class="text-bold"><span style="color: #ff3349">O</span>UR TEAM</h2>
                <hr class="divider bg-primary">
                <div class="range range-xs-center text-lg-left offset-top-60">
                    <div class="cell-xs-8 cell-sm-5 cell-lg-3">
                        <!-- Box Member-->
                        <div class="box-member"><img class="img-responsive center-block"
                                                     src="wt_61187/images/users/mark-johnson-270x270.jpg"
                                                     width="270" height="270" alt="">

                            <div class="offset-top-20">
                                <h5 class="box-member-title text-bold text-primary"><a href="team-member-profile.html">Mark
                                        Johnson</a></h5>
                            </div>
                            <div class="offset-top-6">
                                <p class="text-gray">Founder, CEO</p>
                            </div>
                            <div class="offset-top-10 offset-md-top-20">
                                <ul class="list-inline list-inline-2">
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-facebook"
                                           href="#"></a></li>
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-twitter"
                                           href="#"></a></li>
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-google-plus"
                                           href="#"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="cell-xs-8 cell-sm-5 cell-lg-3 offset-top-69 offset-sm-top-0">
                        <!-- Box Member-->
                        <div class="box-member"><img class="img-responsive center-block"
                                                     src="wt_61187/images/users/edna-barton-270x270.jpg"
                                                     width="270" height="270" alt="">

                            <div class="offset-top-20">
                                <h5 class="box-member-title text-bold text-primary"><a href="team-member-profile.html">Edna
                                        Barton</a></h5>
                            </div>
                            <div class="offset-top-6">
                                <p class="text-gray">Finance Director</p>
                            </div>
                            <div class="offset-top-10 offset-md-top-20">
                                <ul class="list-inline list-inline-2">
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-facebook"
                                           href="#"></a></li>
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-twitter"
                                           href="#"></a></li>
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-google-plus"
                                           href="#"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="cell-xs-8 cell-sm-5 cell-lg-3 offset-top-69 offset-lg-top-0">
                        <!-- Box Member-->
                        <div class="box-member"><img class="img-responsive center-block"
                                                     src="wt_61187/images/users/patrick-pool-270x270.jpg"
                                                     width="270" height="270" alt="">

                            <div class="offset-top-20">
                                <h5 class="box-member-title text-bold text-primary"><a href="team-member-profile.html">Patrick
                                        Pool</a></h5>
                            </div>
                            <div class="offset-top-6">
                                <p class="text-gray">Manager</p>
                            </div>
                            <div class="offset-top-10 offset-md-top-20">
                                <ul class="list-inline list-inline-2">
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-facebook"
                                           href="#"></a></li>
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-twitter"
                                           href="#"></a></li>
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-google-plus"
                                           href="#"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="cell-xs-8 cell-sm-5 cell-lg-3 offset-top-69 offset-lg-top-0">
                        <div class="box-member"><img class="img-responsive center-block"
                                                     src="wt_61187/images/users/dayle-peters-270x270.jpg"
                                                     width="270" height="270" alt="">

                            <div class="offset-top-20">
                                <h5 class="box-member-title text-bold text-primary"><a href="team-member-profile.html">Dayle
                                        Peters</a></h5>
                            </div>
                            <div class="offset-top-6">
                                <p class="text-gray">Travel Agent</p>
                            </div>
                            <div class="offset-top-10 offset-md-top-20">
                                <ul class="list-inline list-inline-2">
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-facebook"
                                           href="#"></a></li>
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-twitter"
                                           href="#"></a></li>
                                    <li><a class="icon icon-xxs icon-teal-blue-filled icon-circle fa fa-google-plus"
                                           href="#"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <br>
        <br>
    </main>
    <!-- Page Footer-->
    <!-- Footer Minimal Dark-->
    <?php include "foot.php"; ?>
</div>
<!-- Global Mailform Output-->
<div class="snackbars" id="form-output-global"></div>
<!-- PhotoSwipe Gallery-->
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="pswp__bg"></div>
    <div class="pswp__scroll-wrap">
        <div class="pswp__container">
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
        </div>
        <div class="pswp__ui pswp__ui--hidden">
            <div class="pswp__top-bar">
                <div class="pswp__counter"></div>
                <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
                <button class="pswp__button pswp__button--share" title="Share"></button>
                <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>
                <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
                <div class="pswp__preloader">
                    <div class="pswp__preloader__icn">
                        <div class="pswp__preloader__cut">
                            <div class="pswp__preloader__donut"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                <div class="pswp__share-tooltip"></div>
            </div>
            <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button>
            <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button>
            <div class="pswp__caption">
                <div class="pswp__caption__center"></div>
            </div>
        </div>
    </div>
</div>
<!-- Java script-->
<script src="wt_61187/js/core.min.js"></script>
<script src="wt_61187/js/script.js"></script>
</body><!-- Google Tag Manager -->
<noscript>
    <iframe src="http://www.googletagmanager.com/ns.html?id=GTM-P9FT69" height="0" width="0"
            style="display:none;visibility:hidden"></iframe>
</noscript>
<script>(function (w, d, s, l, i) {
    w[l] = w[l] || [];
    w[l].push({'gtm.start': new Date().getTime(), event: 'gtm.js'});
    var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
    j.async = true;
    j.src = '../../www.googletagmanager.com/gtm5445.html?id=' + i + dl;
    f.parentNode.insertBefore(j, f);
})(window, document, 'script', 'dataLayer', 'GTM-P9FT69');</script><!-- End Google Tag Manager -->

<!-- Mirrored from livedemo00.template-help.com/wt_61187/our-history.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Aug 2019 12:12:49 GMT -->
</html>