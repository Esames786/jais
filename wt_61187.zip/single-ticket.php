<!DOCTYPE html>
<html class="wide wow-animation smoothscroll scrollTo" lang="en">
  
<!-- Mirrored from livedemo00.template-help.com/wt_61187/single-ticket.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Aug 2019 12:13:27 GMT -->
<head>
    <!-- Site Title-->
    <title>Single Ticket</title>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="icon" href="http://static.livedemo00.template-help.com/wt_61187/images/favicon.ico" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,700%7CLato:400">
    <link rel="stylesheet" href="wt_61187/css/style.css">
		<!--[if lt IE 10]>
    <div style="background: #212121; padding: 10px 0; box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3); clear: both; text-align:center; position: relative; z-index:1;"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <script src="js/html5shiv.min.js"></script>
		<![endif]-->
  </head>
  <body>
    <!-- Page-->
    <div class="page text-center">
      <!-- Page Head-->
      <header class="page-head slider-menu-position">
        <!-- RD Navbar Transparent-->
        <?php include "bar.php" ?>
        <!-- Modern Breadcrumbs-->
        <section
                class="section parallax-container section-height-800 breadcrumb-modern context-dark bg-teal-blue text-lg-left"
                data-parallax-img="images/backgrounds/travel-2.jpg">
            <div class="parallax-content">
                <div class="shell section-30 section-md-top-125 section-lg-top-210">
                    <div class="veil reveal-md-block">
                        <h1 class="text-bold">Ticket Booking</h1>
                    </div>
                    <ul class="list-inline list-inline-icon list-inline-icon-type-1 list-inline-icon-extra-small list-inline-icon-white p offset-md-top-30 offset-md-top-40 offset-lg-top-125">
                        <li><a class="text-white" href="index-2.html">Home</a></li>
                        <li><a class="text-white" href="#">Ticket Booking</a></li>
                        <!-- <li>Services
                        </li> -->
                    </ul>
                </div>
            </div>
        </section>
    </header>
      <!-- Page Contents-->
      <main class="page-content">
        <!-- Single Ticket-->
        <section class="section-90 section-md-60 context-dark bg-link-water text-left">
          <div class="shell">
            <div class="range range-xs-center">
              <div class="cell-sm-10 cell-md-12">
                <!-- Panel-->
                <div class="panel panel-md bg-teal-blue context-dark text-lg-left">
                            <h3><span class="small text-bold text-white">Send a Request</span></h3>

                            <form class="offset-top-10 offset-sm-top-15">
                                <div class="group group-bottom">
                                    <div class="group-item element-fullwidth element-fullwidth-lg">
                                        <div class="form-group text-left">
                                            <label class="form-label form-label-outside"
                                                   for="form-filter-location-from">Traveling From</label>

                                            <div class="select2-whitout-border shadow-drop-md">
                                                <select class="form-control" id="form-filter-location-from"
                                                        name="location-from" data-minimum-results-for-search="Infinity">
                                                    <option value="1">Karachi</option>
                                                    <option value="2">Hyderabad</option>
                                                    <option value="3">Lahore</option>
                                                    <option value="4">Islamabad</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="group-item element-fullwidth element-fullwidth-lg">
                                        <div class="form-group text-left">
                                            <label class="form-label form-label-outside" for="form-filter-location-to">Traveling
                                                To</label>

                                            <div class="select2-whitout-border shadow-drop-md">
                                                <select class="form-control" id="form-filter-location-to"
                                                        name="location-to" data-minimum-results-for-search="Infinity">
                                                    <option value="1">Dubai</option>
                                                    <option value="2">Saudia</option>
                                                    <option value="3">Malaysia</option>
                                                    <option value="4">China</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="group-item element-fullwidth element-fullwidth-xs">
                                        <div class="form-group text-left">
                                            <label class="form-label form-label-outside"
                                                   for="form-filter-location-from-date">Departure & Arival Date</label>

                                            <div class="select2-whitout-border shadow-drop-md">
                                                <select class="form-control" id="form-filter-location-from-date"
                                                        name="date-from" data-minimum-results-for-search="Infinity">
                                                    <option value="1">7-11-2016</option>
                                                    <option value="2">2-12-2016</option>
                                                    <option value="3">14-11-2016</option>
                                                    <option value="4">3-10-2016</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="group-item element-fullwidth element-fullwidth-xs">
                                        <div class="form-group text-left">
                                            <label class="form-label form-label-outside"
                                                   for="form-filter-location-to-date">Ticket Type</label>

                                            <div class="select2-whitout-border shadow-drop-md">
                                                <select class="form-control" id="form-filter-location-to-date"
                                                        name="date-to" data-minimum-results-for-search="Infinity">
                                                    <option value="1">One Way</option>
                                                    <option value="2">Round Trip</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="group-item element-fullwidth element-fullwidth-lg">
                                        <div class="form-group text-left">
                                            <label class="form-label form-label-outside" for="form-filter-location-to">
                                            AirLine</label>

                                            <div class="select2-whitout-border shadow-drop-md">
                                                <select class="form-control" id="form-filter-location-to"
                                                        name="location-to" data-minimum-results-for-search="Infinity">
                                                     <option value="2">PIA</option>
                                                    <option value="2">Emirates</option>
                                                    <option value="3">Fly Dubai</option>
                                                    <option value="4">Qatar Airways</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                   
                                    <div class="group-item element-fullwidth element-fullwidth-sm offset-lg-top-4">
                                        <div class="form-group text-left">
                                            <label class="form-label form-label-outside" for="passengers">Adults</label>

                                            <div class="select2-whitout-border shadow-drop-md">
                                                <select class="form-control" id="passengers" name="passengers"
                                                        data-minimum-results-for-search="Infinity">
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="2">4</option>

                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="group-item element-fullwidth element-fullwidth-sm offset-lg-top-4">
                                        <div class="form-group text-left">
                                            <label class="form-label form-label-outside" for="passengers">Child</label>

                                            <div class="select2-whitout-border shadow-drop-md">
                                                <select class="form-control" id="passengers" name="passengers"
                                                        data-minimum-results-for-search="Infinity">
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="2">4</option>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="group-item element-fullwidth element-fullwidth-sm offset-lg-top-4">
                                        <div class="form-group text-left">
                                            <label class="form-label form-label-outside"
                                                   for="passengers">Infants</label>

                                            <div class="select2-whitout-border shadow-drop-md">
                                                <select class="form-control" id="passengers" name="passengers"
                                                        data-minimum-results-for-search="Infinity">
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="2">4</option>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="group-item element-fullwidth element-fullwidth-md offset-lg-top-4">
                                        <button class="shadow-drop-md btn btn-block btn-primary-inverse" type="button">
                                            Send
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                <div class="offset-top-60">
                  <!-- Table Schedule-->
                  <div class="table-schedule-wrap">
                    <div class="table-schedule">
                      <div class="table-schedule-header">
                                                <!-- List Inline-->
                                                <ul class="list-inline">
                                                  <li class="table-schedule-last-day"><a class="text-bold" href="#"><span class='veil reveal-md-inline-block'></span> Emirates</a></li>
                                                  <li class="table-schedule-last-day"><a class="text-bold" href="#"><span class='veil reveal-md-inline-block'>PIA</span></a></li>
                                                  <li class="active"><a class="text-bold" href="#"><span class='veil reveal-md-inline-block'>Qatar Airways</span></a></li>
                                                  <li><a class="text-bold" href="#"><span class='veil reveal-md-inline-block'>Saudia Airline</span></a></li>
                                                  <li><a class="text-bold" href="#"><span class='veil reveal-md-inline-block'>kuwait Airways</span></a></li>
                                                  <li><a class="text-bold" href="#"><span class='veil reveal-md-inline-block'>SriLankan Airlines</span></a></li>
                                                  <li><a class="text-bold" href="#"><span class='veil reveal-md-inline-block'>Airblue</span></a></li>
                                                  <li><a class="text-bold" href="#"><span class='veil reveal-md-inline-block'>SereneAir</span></a></li>
                                                  <li><a class="text-bold" href="#"><span class='veil reveal-md-inline-block'></span>FlyDubai</a></li>
                                                </ul>
                      </div>
                      <div class="table-schedule-body bg-white">
                        <!-- Classic Responsive Table-->
                        <table class="table table-custom table-fixed table-hover-rows">
                          <tr>
                            <th>Start date</th>
                            <th>End date</th>
                            <th>Rating</th>
                            <th>Tour ID</th>
                            <th>Price</th>
                            <th></th>
                          </tr>
                          <tr>
                            <td>06/10</td>
                            <td>10/10</td>
                            <td>
                              <div class="inset-lg-left-10">
                                <!-- Icon List-->
                                <ul class="list-inline list-inline-size-14 list-inline-0 text-primary">
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star-half-o"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star-o"></span></li>
                                </ul>
                              </div>
                            </td>
                            <td>ABC321</td>
                            <td class="text-bold text-gray-darker">$155.00</td>
                            <td class="p text-bold text-primary"><a href="#">Buy Now</a></td>
                          </tr>
                          <tr>
                            <td>06/10</td>
                            <td>10/10</td>
                            <td>
                              <div class="inset-lg-left-10">
                                <!-- Icon List-->
                                <ul class="list-inline list-inline-size-14 list-inline-0 text-primary">
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star-half-o"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star-o"></span></li>
                                </ul>
                              </div>
                            </td>
                            <td>GHJ654</td>
                            <td class="text-bold text-gray-darker">$186.20</td>
                            <td class="p text-bold text-primary"><a href="#">Buy Now</a></td>
                          </tr>
                          <tr>
                            <td>06/10</td>
                            <td>10/10</td>
                            <td>
                              <div class="inset-lg-left-10">
                                <!-- Icon List-->
                                <ul class="list-inline list-inline-size-14 list-inline-0 text-primary">
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star-half-o"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star-o"></span></li>
                                </ul>
                              </div>
                            </td>
                            <td>QWE987</td>
                            <td class="text-bold text-gray-darker">$194.95</td>
                            <td class="p text-bold text-primary"><a href="#">Buy Now</a></td>
                          </tr>
                          <tr>
                            <td>06/10</td>
                            <td>10/10</td>
                            <td>
                              <div class="inset-lg-left-10">
                                <!-- Icon List-->
                                <ul class="list-inline list-inline-size-14 list-inline-0 text-primary">
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star-half-o"></span></li>
                                  <li><span class="icon icon-xxs fa fa-star-o"></span></li>
                                </ul>
                              </div>
                            </td>
                            <td>IUY951</td>
                            <td class="text-bold text-gray-darker">$125.25</td>
                            <td class="p text-bold text-primary"><a href="#">Buy Now</a></td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <!-- Page Footer-->
      <!-- Footer Minimal Dark-->
      <?php include "foot.php"; ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- PhotoSwipe Gallery-->
    <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="pswp__bg"></div>
      <div class="pswp__scroll-wrap">
        <div class="pswp__container">
          <div class="pswp__item"></div>
          <div class="pswp__item"></div>
          <div class="pswp__item"></div>
        </div>
        <div class="pswp__ui pswp__ui--hidden">
          <div class="pswp__top-bar">
            <div class="pswp__counter"></div>
            <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
            <button class="pswp__button pswp__button--share" title="Share"></button>
            <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>
            <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
            <div class="pswp__preloader">
              <div class="pswp__preloader__icn">
                <div class="pswp__preloader__cut">
                  <div class="pswp__preloader__donut"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
            <div class="pswp__share-tooltip"></div>
          </div>
          <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button>
          <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button>
          <div class="pswp__caption">
            <div class="pswp__caption__center"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Java script-->
    <script src="wt_61187/js/core.min.js"></script>
    <script src="wt_61187/js/script.js"></script>
  </body><!-- Google Tag Manager --><noscript><iframe src="http://www.googletagmanager.com/ns.html?id=GTM-P9FT69"height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-P9FT69');</script><!-- End Google Tag Manager -->

<!-- Mirrored from livedemo00.template-help.com/wt_61187/single-ticket.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Aug 2019 12:13:27 GMT -->
</html>