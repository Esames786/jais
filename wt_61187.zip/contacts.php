<!DOCTYPE html>
<html class="wide wow-animation smoothscroll scrollTo" lang="en">

<!-- Mirrored from livedemo00.template-help.com/wt_61187/contacts.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Aug 2019 12:19:51 GMT -->
<head>
    <!-- Site Title-->
    <title>Contacts</title>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport"
          content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="icon" href="http://static.livedemo00.template-help.com/wt_61187/images/favicon.ico" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css"
          href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,700%7CLato:400">
    <link rel="stylesheet" href="wt_61187/css/style.css">
    <!--[if lt IE 10]>
    <div style="background: #212121; padding: 10px 0; box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3); clear: both; text-align:center; position: relative; z-index:1;"></div>
    <script src="js/html5shiv.min.js"></script>
    <![endif]-->
</head>
<body>
<!-- Page-->
<div class="page text-center">
    <!-- Page Head-->
    <header class="page-head slider-menu-position">
        <!-- RD Navbar Transparent-->
        <?php include "bar.php" ?>
        <!-- Modern Breadcrumbs-->
        <section
                class="section parallax-container section-height-800 breadcrumb-modern context-dark bg-teal-blue text-lg-left"
                data-parallax-img="images/backgrounds/travel-2.jpg">
            <div class="parallax-content">
                <div class="shell section-30 section-md-top-125 section-lg-top-210">
                    <div class="veil reveal-md-block">
                        <h1 class="text-bold">Contact Us</h1>
                    </div>
                    <ul class="list-inline list-inline-icon list-inline-icon-type-1 list-inline-icon-extra-small list-inline-icon-white p offset-md-top-30 offset-md-top-40 offset-lg-top-125">
                        <li><a class="text-white" href="index-2.html">Home</a></li>
                        <li><a class="text-white" href="#">Contact Us</a></li>
                        <!-- <li>Services
                        </li> -->
                    </ul>
                </div>
            </div>
        </section>
    </header>
    <!-- Page Contents-->
    <main class="page-content">
        <!-- Get in touch-->
        <section class="section-90 section-md-111 text-left">
            <div class="shell">
                <div class="range range-xs-center">
                    <div class="cell-xs-10 cell-md-8">
                        <div class="inset-lg-right-40">
                            <h2 class="text-bold text-center text-md-left">Get in Touch</h2>
                            <hr class="divider hr-sm-left-0 bg-primary">
                            <div class="offset-top-35 offset-md-top-65">
                                <p>You can contact us any way that is convenient for you. We are available 24/7 via fax
                                    or email. You can also use a quick contact form below or visit our office
                                    personally.</p>
                            </div>
                            <div class="offset-top-6">
                                <p>We would be happy to answer your questions.</p>
                            </div>
                            <div class="offset-top-20 offset-md-top-30">
                                <!-- RD Mailform-->
                                <form class="rd-mailform text-left" data-form-output="form-output-global"
                                      data-form-type="contact" method="post"
                                      action="http://livedemo00.template-help.com/wt_61187/bat/rd-mailform.php">
                                    <div class="range range-xs-center">
                                        <div class="cell-sm-6">
                                            <div class="form-group form-group-label-outside">
                                                <label class="form-label form-label-outside text-dark"
                                                       for="contacts-first-name">First name</label>
                                                <input class="form-control" id="contacts-first-name" type="text"
                                                       name="first-name" data-constraints="@Required">
                                            </div>
                                            <div class="form-group form-group-label-outside offset-top-20">
                                                <label class="form-label form-label-outside text-dark"
                                                       for="contacts-email">E-mail</label>
                                                <input class="form-control" id="contacts-email" type="email"
                                                       name="email" data-constraints="@Email @Required">
                                            </div>
                                        </div>
                                        <div class="cell-sm-6 offset-top-20 offset-sm-top-0">
                                            <div class="form-group form-group-label-outside">
                                                <label class="form-label form-label-outside text-dark"
                                                       for="contacts-last-name">Last name</label>
                                                <input class="form-control" id="contacts-last-name" type="text"
                                                       name="last-name" data-constraints="@Required">
                                            </div>
                                            <div class="form-group form-group-label-outside offset-top-20">
                                                <label class="form-label form-label-outside text-dark"
                                                       for="contacts-phone">Phone</label>
                                                <input class="form-control" id="contacts-phone" type="text"
                                                       name="last-name" data-constraints="@IsNumeric @Required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group form-group-label-outside offset-top-20">
                                        <label class="form-label form-label-outside text-dark" for="contacts-message">Message</label>
                                        <textarea class="form-control" id="contacts-message" name="message"
                                                  data-constraints="@Required" style="max-height: 150px;"></textarea>
                                    </div>
                                    <div class="offset-top-18 offset-sm-top-30 text-center text-sm-left">
                                        <button class="btn btn-primary" type="submit">Send Message</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="cell-xs-10 cell-md-4 offset-top-60 offset-md-top-0">
                        <!-- Sidebar-->
                        <aside class="text-left">
                            <div class="inset-md-left-30">
                                <!-- Socials-->
                                <div>
                                    <h5 class="text-bold">Socials</h5>
                                </div>
                                <div class="offset-top-6">
                                    <div class="text-subline"></div>
                                </div>
                                <div class="offset-top-20">
                                    <ul class="list-inline list-inline-2">
                                        <li><a class="icon icon-xxs icon-silver-filled icon-circle fa fa-facebook"
                                               href="#"></a></li>
                                        <li><a class="icon icon-xxs icon-silver-filled icon-circle fa fa-twitter"
                                               href="#"></a></li>
                                        <li><a class="icon icon-xxs icon-silver-filled icon-circle fa fa-google-plus"
                                               href="#"></a></li>
                                        <li><a class="icon icon-xxs icon-silver-filled icon-circle fa fa-instagram"
                                               href="#"></a></li>
                                        <li><a class="icon icon-xxs icon-silver-filled icon-circle fa fa-rss"
                                               href="#"></a></li>
                                    </ul>
                                </div>
                                <!-- Phones-->
                                <div class="offset-top-30 offset-md-top-60">
                                    <div>
                                        <h5 class="text-bold">Phones</h5>
                                    </div>
                                    <div class="offset-top-6">
                                        <div class="text-subline"></div>
                                    </div>
                                    <div class="offset-top-20">
                                        <div class="unit unit-middle unit-horizontal unit-spacing-xs">
                                            <div class="unit-left"><span
                                                    class="icon icon-xxs icon-primary icon-primary-filled icon-circle mdi mdi-phone"></span>
                                            </div>
                                            <div class="unit-body text-gray-darker">
                                                <p><a class="reveal-block reveal-xs-inline-block text-gray-darker"
                                                      href="callto:#">+92-21-35631235-37</a><span
                                                        class="veil reveal-xs-inline-block"> &nbsp;</span><a
                                                        class="reveal-block reveal-xs-inline-block text-gray-darker"
                                                        href="callto:#"></a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- E-mail-->
                                <div class="offset-top-30 offset-md-top-60">
                                    <div>
                                        <h5 class="text-bold">E-mail</h5>
                                    </div>
                                    <div class="offset-top-6">
                                        <div class="text-subline"></div>
                                    </div>
                                    <div class="offset-top-20">
                                        <div class="unit unit-middle unit-horizontal unit-spacing-xs">
                                            <div class="unit-left"><span
                                                    class="icon icon-xxs icon-primary icon-primary-filled icon-circle mdi mdi-email-outline"></span>
                                            </div>
                                            <div class="unit-body">
                                                <p><a class="text-primary"
                                                      href=""><span>info@jaisinternational.com</span></a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Address-->
                                <div class="offset-top-30 offset-md-top-60">
                                    <div>
                                        <h5 class="text-bold">Address</h5>
                                    </div>
                                    <div class="offset-top-6">
                                        <div class="text-subline"></div>
                                    </div>
                                    <div class="offset-top-20">
                                        <div class="unit unit-horizontal unit-spacing-xs">
                                            <div class="unit-left"><span
                                                    class="icon icon-xxs icon-primary icon-primary-filled icon-circle mdi mdi-map-marker"></span>
                                            </div>
                                            <div class="unit-body">
                                                <p><a class="text-gray-darker" href="#">Suite # 516, 5th Floor, Madina
                                                    City Mall <br class="veil reveal-sm-inline-block"> Near Zainab
                                                    Market, Abdullah Haroon Road, Saddar, Karachi-74200, Pakistan.</a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Opening Hours-->
                                <div class="offset-top-30 offset-md-top-60">
                                    <div>
                                        <h5 class="text-bold">Opening Hours</h5>
                                    </div>
                                    <div class="offset-top-6">
                                        <div class="text-subline"></div>
                                    </div>
                                    <div class="offset-top-20">
                                        <div class="unit unit-horizontal unit-spacing-xs">
                                            <div class="unit-left"><span
                                                    class="icon icon-xxs icon-primary icon-primary-filled icon-circle mdi mdi-calendar-clock"></span>
                                            </div>
                                            <div class="unit-body">
                                                <p class="text-gray-darker">Mon-Fri: 10:00am–6:00pm</p>

                                                <p class="text-gray-darker">Sat: 10:00am–4:00pm</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </aside>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <!-- RD Google Map-->
            <div class="rd-google-map">
                <div class="rd-google-map__model" id="rd-google-map" data-zoom="15" data-x="-73.9874068"
                     data-y="40.643180"
                     data-styles="[{&quot;featureType&quot;:&quot;landscape&quot;,&quot;stylers&quot;:[{&quot;hue&quot;:&quot;#FFBB00&quot;},{&quot;saturation&quot;:43.400000000000006},{&quot;lightness&quot;:37.599999999999994},{&quot;gamma&quot;:1}]},{&quot;featureType&quot;:&quot;road.highway&quot;,&quot;stylers&quot;:[{&quot;hue&quot;:&quot;#FFC200&quot;},{&quot;saturation&quot;:-61.8},{&quot;lightness&quot;:45.599999999999994},{&quot;gamma&quot;:1}]},{&quot;featureType&quot;:&quot;road.arterial&quot;,&quot;stylers&quot;:[{&quot;hue&quot;:&quot;#FF0300&quot;},{&quot;saturation&quot;:-100},{&quot;lightness&quot;:51.19999999999999},{&quot;gamma&quot;:1}]},{&quot;featureType&quot;:&quot;road.local&quot;,&quot;stylers&quot;:[{&quot;hue&quot;:&quot;#FF0300&quot;},{&quot;saturation&quot;:-100},{&quot;lightness&quot;:52},{&quot;gamma&quot;:1}]},{&quot;featureType&quot;:&quot;water&quot;,&quot;stylers&quot;:[{&quot;hue&quot;:&quot;#0078FF&quot;},{&quot;saturation&quot;:-13.200000000000003},{&quot;lightness&quot;:2.4000000000000057},{&quot;gamma&quot;:1}]},{&quot;featureType&quot;:&quot;poi&quot;,&quot;stylers&quot;:[{&quot;hue&quot;:&quot;#00FF6A&quot;},{&quot;saturation&quot;:-1.0989010989011234},{&quot;lightness&quot;:11.200000000000017},{&quot;gamma&quot;:1}]}]"></div>
                <ul class="rd-google-map__locations">
                    <li data-x="-73.9874068" data-y="40.643180">
                        <p>9870 St Vincent Place, Glasgow, DC 45 Fr 45</p>
                    </li>
                </ul>
            </div>
        </section>
    </main>
    <!-- Page Footer-->
    <!-- Footer Minimal Dark-->
    <!-- Footer Minimal Dark-->
    <?php include "foot.php"; ?>
</div>
<!-- Global Mailform Output-->
<div class="snackbars" id="form-output-global"></div>
<!-- PhotoSwipe Gallery-->
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="pswp__bg"></div>
    <div class="pswp__scroll-wrap">
        <div class="pswp__container">
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
        </div>
        <div class="pswp__ui pswp__ui--hidden">
            <div class="pswp__top-bar">
                <div class="pswp__counter"></div>
                <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
                <button class="pswp__button pswp__button--share" title="Share"></button>
                <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>
                <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
                <div class="pswp__preloader">
                    <div class="pswp__preloader__icn">
                        <div class="pswp__preloader__cut">
                            <div class="pswp__preloader__donut"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                <div class="pswp__share-tooltip"></div>
            </div>
            <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button>
            <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button>
            <div class="pswp__caption">
                <div class="pswp__caption__center"></div>
            </div>
        </div>
    </div>
</div>
<!-- Java script-->
<script src="wt_61187/js/core.min.js"></script>
<script src="wt_61187/js/script.js"></script>
</body><!-- Google Tag Manager -->
<noscript>
    <iframe src="http://www.googletagmanager.com/ns.html?id=GTM-P9FT69" height="0" width="0"
            style="display:none;visibility:hidden"></iframe>
</noscript>
<script>(function (w, d, s, l, i) {
    w[l] = w[l] || [];
    w[l].push({'gtm.start': new Date().getTime(), event: 'gtm.js'});
    var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
    j.async = true;
    j.src = '../../www.googletagmanager.com/gtm5445.html?id=' + i + dl;
    f.parentNode.insertBefore(j, f);
})(window, document, 'script', 'dataLayer', 'GTM-P9FT69');</script><!-- End Google Tag Manager -->

<!-- Mirrored from livedemo00.template-help.com/wt_61187/contacts.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Aug 2019 12:19:51 GMT -->
</html>