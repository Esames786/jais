<!DOCTYPE html>
<html class="wide wow-animation smoothscroll scrollTo" lang="en">
  
<!-- Mirrored from livedemo00.template-help.com/wt_61187/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Aug 2019 12:09:55 GMT -->
<head>
    <!-- Site Title-->
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,700%7CLato:400">
    <link rel="stylesheet" href="wt_61187/css/style.css">
		<!--[if lt IE 10]>
    <div style="background: #212121; padding: 10px 0; box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3); clear: both; text-align:center; position: relative; z-index:1;"<img src="images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <script src="js/html5shiv.min.js"></script>
		<![endif]-->
  </head>
  <body>
    <!-- Page-->
    <div class="page text-center">
      <!-- Page Head-->
      <header class="page-head slider-menu-position">
        <!-- RD Navbar Transparent-->
        <?php include "bar.php" ;?>
        <!-- Swiper-->
        <div class="swiper-bg-wrap">
          <div class="swiper-container swiper-slider text-lg-left" data-height="" data-min-height="200px" data-slide-effect="fade" data-simulate-touch="false" data-autoplay="2500">
            <div class="swiper-wrapper">
              <div class="swiper-slide" data-slide-bg="images/backgrounds/travel-1.jpg"></div>
              <div class="swiper-slide" data-slide-bg="images/backgrounds/travel-2.jpg"></div>
              <div class="swiper-slide" data-slide-bg="images/backgrounds/travel-3.jpg"></div>
            </div>
          </div>
          <div class="swiper-bg-content context-dark">
            <div class="swiper-bg-inner">
              <div class="shell">
                <div class="range range-xs-center">
                  <div class="cell-xs-12">
                    <h1 class="swiper-header text-bold">We are your ultimate<br class="veil reveal-sm-block"> Travel Services Provider!</h1>
                    <div class="offset-top-20 swiper-text">
                      <p class="h6">With hundreds of destinations offered, we are your<br class="veil reveal-sm-block"> natural choice for planning it all out!</p>
                    </div>
                    <div class="offset-top-42"><a class="btn btn-white-outline" href="services.php">Learn More</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Page Contents-->
      <main class="page-content" id="section-change-color">
        <!-- Why We’re the Best-->
        <section class="context-dark bg-overlay bg-overlay-teal-blue-94 section-90 section-md-111 bg-image" style="background-image: url(wt_61187/images/backgrounds/airplane3.jpg)">
          <div class="shell">
            <h2 class="text-bold">Why We’re the Best</h2>
            <hr class="divider bg-primary">
            <div class="range range-xs-center offset-top-69">
              <div class="cell-xs-6 cell-sm-5 cell-md-3">
                <!-- Box Icon-->
                <div class="box-icon"><span class="icon icon-xlg icon-circle icon-transparent-jelly-bean-filled material-icons-business"></span>
                  <div class="offset-top-20">
                    <h5 class="text-bold">Accommodation</h5>
                  </div>
                  <div class="offset-top-15">
                    <hr class="divider divider-xs bg-jelly-bean"/>
                  </div>
                  <div class="offset-top-15">
                    <p class="text-white">We offer the finest selection of top notch hotels anywhere!</p>
                  </div>
                </div>
              </div>
              <div class="cell-xs-6 cell-sm-5 cell-md-3 offset-top-60 offset-xs-top-0">
                <!-- Box Icon-->
                <div class="box-icon"><span class="icon icon-xlg icon-circle icon-transparent-jelly-bean-filled material-icons-airplanemode_active"></span>
                  <div class="offset-top-20">
                    <h5 class="text-bold">Transportation</h5>
                  </div>
                  <div class="offset-top-15">
                    <hr class="divider divider-xs bg-jelly-bean"/>
                  </div>
                  <div class="offset-top-15">
                    <p class="text-white">Whether it’s about air tickets or shuttle bus, we will set it up!  </p>
                  </div>
                </div>
              </div>
              <div class="cell-xs-6 cell-sm-5 cell-md-3 offset-top-60 offset-md-top-0">
                <!-- Box Icon-->
                <div class="box-icon"><span class="icon icon-xlg icon-circle icon-transparent-jelly-bean-filled material-icons-group"></span>
                  <div class="offset-top-20">
                    <h5 class="text-bold">Seasoned Agents</h5>
                  </div>
                  <div class="offset-top-15">
                    <hr class="divider divider-xs bg-jelly-bean"/>
                  </div>
                  <div class="offset-top-15">
                    <p class="text-white">Combined, the experience our agents have is centuries!</p>
                  </div>
                </div>
              </div>
              <div class="cell-xs-6 cell-sm-5 cell-md-3 offset-top-60 offset-md-top-0">
                <!-- Box Icon-->
                <div class="box-icon"><span class="icon icon-xlg icon-circle icon-transparent-jelly-bean-filled material-icons-grade"></span>
                  <div class="offset-top-20">
                    <h5 class="text-bold">Easy Trip Planning</h5>
                  </div>
                  <div class="offset-top-15">
                    <hr class="divider divider-xs bg-jelly-bean"/>
                  </div>
                  <div class="offset-top-15">
                    <p class="text-white">Our travel agents are always ready to plan your perfect trip!</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- Best Winter Trips-->
        <section class="bg-image" style="background-image: url(wt_61187/images/backgrounds/airplane.jpg);">
          <div class="section-90 section-md-111 bg-overlay bg-overlay-white-06">
            <div class="shell">
              <h2 class="text-teal-blue text-bold">Our Tour Packages</h2>
              <hr class="divider bg-teal-blue">
              <div class="range range-xs-center offset-top-60">
                <div class="cell-xs-10 cell-sm-6">
                  <!-- Post Ticket--><a class="post-ticket post-ticket-boxed" href="destinations.php?id=INTERNATIONAL%20TOURS">
                    <div class="post-ticket-header"><img class="img-responsive" src="wt_61187/images/blog/dubai.jpg" width="570" height="280" alt=""/>
                      <div class="post-ticket-price text-bold text-shark"><span>Rs</span><span>120000.00</span><span>/person.</span></div>
                    </div>
                    <div class="post-ticket-body text-left">
                      <!-- List Inline-->
                      <div>
                        <p class="post-ticket-boxed-title text-bold">Dubai</p>
                      </div>
                    </div></a>
                </div>
                <div class="cell-xs-10 cell-sm-6 offset-top-30 offset-sm-top-0">
                  <!-- Post Ticket--><a class="post-ticket post-ticket-boxed" href="destinations.php?id=INTERNATIONAL%20TOURS">
                    <div class="post-ticket-header"><img class="img-responsive" src="wt_61187/images/blog/dubai.jpg" width="570" height="280" alt=""/>
                      <div class="post-ticket-price text-bold text-shark"><span>Rs</span><span>120000.00</span><span>/person.</span></div>
                    </div>
                    <div class="post-ticket-body text-left">
                      <!-- List Inline-->
                      <div>
                        <p class="post-ticket-boxed-title text-bold">Dubai</p>
                      </div>
                    </div></a>
                </div>
                <div class="cell-xs-10 cell-sm-6 offset-top-30 offset-sm-top-25">
                  <!-- Post Ticket--><a class="post-ticket post-ticket-boxed" href="destinations.php?id=INTERNATIONAL%20TOURS">
                    <div class="post-ticket-header"><img class="img-responsive" src="wt_61187/images/blog/dubai.jpg" width="570" height="280" alt=""/>
                      <div class="post-ticket-price text-bold text-shark"><span>Rs</span><span>120000.00</span><span>/person.</span></div>
                    </div>
                    <div class="post-ticket-body text-left">
                      <!-- List Inline-->
                      <div>
                        <p class="post-ticket-boxed-title text-bold">Dubai</p>
                      </div>
                    </div></a>
                </div>
                <div class="cell-xs-10 cell-sm-6 offset-top-30 offset-sm-top-25">
                  <!-- Post Ticket--><a class="post-ticket post-ticket-boxed" href="destinations.php?id=INTERNATIONAL%20TOURS">
                    <div class="post-ticket-header"><img class="img-responsive" src="wt_61187/images/blog/dubai.jpg" width="570" height="280" alt=""/>
                      <div class="post-ticket-price text-bold text-shark"><span>Rs</span><span>120000.00</span><span>/person.</span></div>
                    </div>
                    <div class="post-ticket-body text-left">
                      <!-- List Inline-->
                      <div>
                        <p class="post-ticket-boxed-title text-bold">Dubai  </p>
                      </div>
                    </div></a>
                </div>
              </div>
              <div class="offset-top-60"><a class="btn btn-primary" href="destinations.php?id=INTERNATIONAL%20TOURS">View All Destinations</a></div>
            </div>
          </div>
          <!-- Special Service-->
          <div class="section-top-90 section-bottom-90 section-md-top-144 section-md-bottom-130 bg-image" style="background-image: url(wt_61187/images/backgrounds/background-image-overlay.png);">
            <div class="shell">
              <div>
                <h5 class="text-bold text-white">Services</h5>
              </div>
              <div class="offset-top-10">
                <h2 class="text-bold text-white">Please Check Our Valuable Services</h2>
              </div>
              <div class="offset-top-42"><a class="btn btn-primary-inverse" href="services.php">Check It</a></div>
            </div>
          </div>
        </section>
       
       
      </main>
      <!-- Page Footer-->
     
       <?php include "foot.php"; ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- PhotoSwipe Gallery-->
    <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="pswp__bg"></div>
      <div class="pswp__scroll-wrap">
        <div class="pswp__container">
          <div class="pswp__item"></div>
          <div class="pswp__item"></div>
          <div class="pswp__item"></div>
        </div>
        <div class="pswp__ui pswp__ui--hidden">
          <div class="pswp__top-bar">
            <div class="pswp__counter"></div>
            <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
            <button class="pswp__button pswp__button--share" title="Share"></button>
            <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>
            <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
            <div class="pswp__preloader">
              <div class="pswp__preloader__icn">
                <div class="pswp__preloader__cut">
                  <div class="pswp__preloader__donut"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
            <div class="pswp__share-tooltip"></div>
          </div>
          <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button>
          <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button>
          <div class="pswp__caption">
            <div class="pswp__caption__center"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Java script-->
    <script src="wt_61187/js/core.min.js"></script>
    <script src="wt_61187/js/script.js"></script>
	
	<!--LIVEDEMO_00 -->

	<script type="text/javascript">
	 var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-7078796-5']);
	  _gaq.push(['_trackPageview']);
	  (function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();</script>
	
  </body><!-- Google Tag Manager --><noscript><iframe src="http://www.googletagmanager.com/ns.html?id=GTM-P9FT69"height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-P9FT69');</script><!-- End Google Tag Manager -->

<!-- Mirrored from livedemo00.template-help.com/wt_61187/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Aug 2019 12:11:38 GMT -->
</html>