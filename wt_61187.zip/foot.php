<footer class="page-footer bg-teal-blue">
        <section class="section-60">
            <div class="shell">
                <div class="range range-xs-center text-md-left">
                    <div class="cell-xs-10 cell-sm-7 cell-md-4">
                        <!-- Footer brand-->
                        <div class="footer-brand"><a href=""><img style = "margin-top : -45px;" width='310' height='200'
                                                                              src='wt_61187/images/jaislogoo.png'
                                                                              alt=''/></a></div>
                        <div class="offset-top-30 inset-sm-right-20">
                            <p class="text-white-08" style = "margin-top : -70px;">If you want best travel and tour packages, Hajj and Umrah packages,
                                if you want visa or hottels so please contact with we provide our best services.</p>
                        </div>
                    </div>
                    <div class="cell-xs-10 cell-sm-7 cell-md-4 offset-top-60 offset-md-top-0">
                        <div>
                            <h5 class="text-bold text-white-08">Contacts</h5>
                        </div>
                        <div class="offset-top-6">
                            <div class="text-subline text-subline-inverse"></div>
                        </div>
                        <div class="offset-top-20">
                            <!-- Contact Info-->
                            <address class="contact-info text-left">
                                <div>
                                    <div class="reveal-inline-block"><a
                                            class="unit unit-middle unit-horizontal unit-spacing-xs"
                                            href=""><span class="unit-left"><span
                                            class="icon icon-xxs icon-primary icon-primary-filled icon-circle mdi mdi-phone"></span></span><span
                                            class="unit-body"><span
                                            class="text-white-08">+92-21-35631235-37</span></span></a></div>
                                </div>
                                <div class="offset-top-10">
                                    <div class="reveal-inline-block"><a
                                            class="unit unit-middle unit-horizontal unit-spacing-xs"
                                            href=""><span class="unit-left"><span
                                            class="icon icon-xxs icon-primary icon-primary-filled icon-circle mdi mdi-email-outline"></span></span><span
                                            class="unit-body"><span class="text-white-08"><span class="__cf_email__"
                                                                                                data-cfemail="375e5951587753525a585b5e595c19584550">info@jaisinternational.com</span></span></span></a>
                                    </div>
                                </div>
                                <div class="offset-top-10">
                                    <div class="reveal-inline-block"><a class="unit unit-horizontal unit-spacing-xs"
                                                                        href="#"><span class="unit-left"><span
                                            class="icon icon-xxs icon-primary icon-primary-filled icon-circle mdi mdi-map-marker"></span></span><span
                                            class="unit-body"><span class="text-white-08">Suite#516, 5th Floor, Madina City <br>Mall Near Zainab Market, Saddar, <br> Karachi 74200, Pakistan</span></span></a>
                                    </div>
                                </div>
                            </address>
                        </div>
                        <div class="offset-top-20">
                            <!-- List Inline-->
                            <ul class="list-inline list-inline-2">
                                <li><a class="icon icon-xxs icon-white-filled icon-circle fa fa-facebook" href="#"></a>
                                </li>
                                <li><a class="icon icon-xxs icon-white-filled icon-circle fa fa-twitter" href="#"></a>
                                </li>
                                <li><a class="icon icon-xxs icon-white-filled icon-circle fa fa-google-plus"
                                       href="#"></a></li>
                                <li><a class="icon icon-xxs icon-white-filled icon-circle fa fa-instagram" href="#"></a>
                                </li>
                                <!-- <li><a class="icon icon-xxs icon-white-filled icon-circle fa fa-rss" href="#"></a></li> -->
                            </ul>
                        </div>
                    </div>
                    <div class="cell-xs-10 cell-sm-7 cell-md-4 offset-top-60 offset-md-top-0">
                        <div>
                            <h5 class="text-bold text-white-08">Suscription</h5>
                        </div>
                        <div class="offset-top-6">
                            <div class="text-subline text-subline-inverse"></div>
                        </div>
                        <div class="offset-top-25">
                            <p class="text-white-08">Enter your email address to get the latest Tour Packages and our
                                special offers.</p>
                        </div>
                        <div class="offset-top-20">
                            <form class="rd-mailform rd-mailform-subscribe" data-form-output="form-subscribe-footer"
                                  data-form-type="subscribe" method="post"
                                  action="http://livedemo00.template-help.com/wt_61187/bat/rd-mailform.php">
                                <div class="form-group form-group-sm">
                                    <div class="input-group">
                                        <input class="form-control" placeholder="Your e-mail..." type="email"
                                               name="email" data-constraints="@Email @Required"><span
                                            class="input-group-btn">
                              <button class="btn btn-xs btn-primary-inverse" type="submit">Subscribe</button></span>
                                    </div>
                                </div>
                                <div class="form-output" id="form-subscribe-footer"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- <section class="section-12 text-md-left">
          <div class="shell">
            <p class="font-accent"><span class="small text-white-08">&copy; <span id="copyright-year"></span> All Rights Reserved Terms of Use and <a href="privacy.html">Privacy Policy</a></span></p>
          </div>
        </section> -->
    </footer>