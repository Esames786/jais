<!DOCTYPE html>
<html class="wide wow-animation smoothscroll scrollTo" lang="en">
  
<!-- Mirrored from livedemo00.template-help.com/wt_61187/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Aug 2019 12:19:05 GMT -->
<head>
    <!-- Site Title-->
    <title>Services</title>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="icon" href="http://static.livedemo00.template-help.com/wt_61187/images/favicon.ico" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto:400,400italic,700%7CLato:400">
    <link rel="stylesheet" href="wt_61187/css/style.css">
		<!--[if lt IE 10]>
    <div style="background: #212121; padding: 10px 0; box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3); clear: both; text-align:center; position: relative; z-index:1;"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <script src="js/html5shiv.min.js"></script>
		<![endif]-->
  </head>
  <body>
    <!-- Page-->
    <div class="page text-center">
      <!-- Page Head-->
      <header class="page-head slider-menu-position">
        <!-- RD Navbar Transparent-->
        <div class="rd-navbar-wrap">
          <nav class="rd-navbar rd-navbar-top-panel rd-navbar-default rd-navbar-white rd-navbar-static-fullwidth-transparent" data-md-device-layout="rd-navbar-fixed" data-lg-device-layout="rd-navbar-static" data-md-stick-up-offset="90px" data-lg-stick-up-offset="75px" data-auto-height="false" data-lg-auto-height="true" data-md-layout="rd-navbar-fullwidth" data-lg-layout="rd-navbar-static" data-lg-stick-up="true">
            <div class="rd-navbar-inner">
              <!-- RD Navbar Panel-->
              <div class="rd-navbar-panel">
                <!-- RD Navbar Toggle-->
                <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar, .rd-navbar-nav-wrap"><span></span></button>
                <!-- Navbar Brand-->
                <div class="rd-navbar-brand"><a href="index-2.html"><img width='60' height='60' src='wt_61187/images/jaislogo.png' alt=''/>  </a> <p style = "display:inline;" color = "#bf9f62;">  Jais International</p> </div>
              </div>
              <div class="rd-navbar-menu-wrap">
                <div class="rd-navbar-nav-wrap">
                  <div class="rd-navbar-mobile-scroll">
                    <!-- Navbar Brand Mobile-->
                    <div class="rd-navbar-mobile-brand"><a href="index-2.html"><img width='50' height='50' src='wt_61187/images/jaislogo.png' alt=''/></a></div>
                    <!-- RD Navbar Nav-->
                    <ul class="rd-navbar-nav">
                      <li><a href="index.php">Home</a></li>
                      <li><a href="our-history.php">About</a>
                        <!-- RD Navbar Dropdown-->
                        <!-- <ul class="rd-navbar-dropdown">
                          <li><a href="our-history.php">Our History</a></li>
                          <li><a href="our-team.html">Our Team</a></li>
                          <li><a href="testimonials.html">Testimonials</a></li>
                          <li><a href="faq.html">FAQ Page</a></li>
                          <li><a href="press.html">Press</a></li>
                        </ul> -->
                      </li>
                      <li><a href="international-tour.php">Tours</a>
                        <!-- RD Navbar Dropdown-->
                        <ul class="rd-navbar-dropdown">
                        
                          <li><a href="international-tour.php">International Tour</a></li>
                          <li><a href="domestic-tour.html">Domestic Tour</a></li>
                          
                        </ul>
                      </li>
                      <li><a href="blog-classic.html">News</a>
                        <!-- RD Navbar Dropdown-->
                        <ul class="rd-navbar-dropdown">
                          <li><a href="blog-classic.html">Classic Blog</a></li>
                          <li><a href="blog-grid.html">Grid Blog</a></li>
                          <li><a href="blog-masonry.html">Masonry Blog</a></li>
                          <li><a href="blog-modern.html">Modern Blog</a></li>
                          <li><a href="single-post.html">Post Page</a></li>
                        </ul>
                      </li>
                      <li><a href="schedule.php">Schedule</a></li>
                      <li><a href="#">Gallery</a>
                        <!-- RD Navbar Dropdown-->
                        <ul class="rd-navbar-dropdown">
                          <li><a href="grid-gallery.html">Grid Gallery</a></li>
                          <li><a href="grid-without-padding-gallery.html">Grid Without Padding Gallery</a></li>
                          <li><a href="masonry-gallery.html">Masonry Gallery</a></li>
                          <li><a href="cobbles-gallery.html">Cobbles Gallery</a></li>
                        </ul>
                      </li>
                      <li class="active"><a href="#">Pages</a>
                        <div class="rd-navbar-megamenu">
                          <div class="row">
                            <div class="col-md-3">
                              <div class="veil reveal-md-block">
                                <h6 class="text-bold">Gallery</h6>
                              </div>
                              <ul class="offset-md-top-20">
                                <li><a href="grid-gallery.html">Grid Gallery</a></li>
                                <li><a href="grid-without-padding-gallery.html">Grid Without Padding Gallery</a></li>
                                <li><a href="masonry-gallery.html">Masonry Gallery</a></li>
                                <li><a href="cobbles-gallery.html">Cobbles Gallery</a></li>
                              </ul>
                            </div>
                            <div class="col-md-3">
                              <div class="veil reveal-md-block">
                                <h6 class="text-bold">Elements</h6>
                              </div>
                              <ul class="offset-md-top-20">
                                <li><a href="typography.html">Typography</a></li>
                                <li><a href="tabs-accordions.html">Tabs &amp; Accordions</a></li>
                                <li><a href="progress-bars.html">Progress Bars</a></li>
                                <li><a href="tables.html">Tables</a></li>
                                <li><a href="forms.html">Forms</a></li>
                                <li><a href="buttons.html">Buttons</a></li>
                                <li><a href="icons.html">Icons</a></li>
                                <li><a href="grid.html">Grid</a></li>
                              </ul>
                            </div>
                            <div class="col-md-3">
                              <div class="veil reveal-md-block">
                                <h6 class="text-bold">Pages</h6>
                              </div>
                              <ul class="offset-md-top-20">
                                <li><a href="deals.html">Deals</a></li>
                                <li><a href="team-member-profile.html">Team Member Profile</a></li>
                                <li><a href="services.html">Services</a></li>
                                <li><a href="sitemap.html">Sitemap</a></li>
                                <li><a href="404.html">404 Page</a></li>
                                <li><a href="503.html">503 Page</a></li>
                                <li><a href="under-construction.html">Under Construction</a></li>
                                <li><a href="login-register.html">Login/Register</a></li>
                                <li><a href="privacy.html">Terms of Use</a></li>
                                <li><a href="single-service.html">Single Service</a></li>
                              </ul>
                            </div>
                            <div class="col-md-3">
                              <div class="veil reveal-md-block">
                                <h6 class="text-bold">Layouts</h6>
                              </div>
                              <ul class="offset-md-top-20">
                                <li><a href="transparent-header.html">Transparent Header</a></li>
                                <li><a href="corporate-header.html">Corporate Header</a></li>
                                <li><a href="minimal-header.html">Minimal Header</a></li>
                                <li><a href="hamburger-menu-header.html">Hamburger Menu Header</a></li>
                                <li><a href="footer-widget-light.html">Footer Widget Light</a></li>
                                <li><a href="footer-widget-dark.html">Footer Widget Dark</a></li>
                                <li><a href="footer-center-light.html">Footer Center Light</a></li>
                                <li><a href="footer-center-dark.html">Footer Center Dark</a></li>
                                <li><a href="footer-minimal-light.html">Footer Minimal Light</a></li>
                                <li><a href="footer-minimal-dark.html">Footer Minimal Dark</a></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li><a href="contacts.php">Contacts</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </nav>
        </div>
        <!-- Modern Breadcrumbs-->
        <section class="section parallax-container section-height-800 breadcrumb-modern context-dark bg-teal-blue text-lg-left" data-parallax-img="images/backgrounds/travel-2.jpg">
          <div class="parallax-content">
            <div class="shell section-30 section-md-top-125 section-lg-top-210">
              <div class="veil reveal-md-block">
                <h1 class="text-bold">Services</h1>
              </div>
              <ul class="list-inline list-inline-icon list-inline-icon-type-1 list-inline-icon-extra-small list-inline-icon-white p offset-md-top-30 offset-md-top-40 offset-lg-top-125">
                <li><a class="text-white" href="index-2.html">Home</a></li>
                <li><a class="text-white" href="#">Services</a></li>
                <!-- <li>Services
                </li> -->
              </ul>
            </div>
          </div>
        </section>
      </header>





      
      <!-- Page Contents-->
      <main class="page-content">
        <section class="section-60 section-sm-0">
          <div class="shell">
            <div class="range range-xs-center range-sm-right">
              <div class="cell-xs-10 cell-sm-6 section-image-aside section-image-aside-left text-left">
                <div class="section-image-aside-img veil reveal-sm-block" style="background-image: url(wt_61187/images/pages/at1.jpg); background-position: center center;"></div>
                <div class="section-image-aside-body section-sm-top-90 section-sm-bottom-90 section-md-top-111 section-md-bottom-162 inset-sm-left-50 inset-lg-left-100">
                  <h2 class="text-bold text-center text-sm-left">Air Tickets</h2>
                  <hr class="divider hr-sm-left-0 bg-primary">
                  <div class="offset-top-30 offset-md-top-60">
                    <p>Most places that a modern tourist from the US wants to go to require air traveling. For our agency, this was the reason to start offering a wide selection of the best, cheapest airline tickets to numerous destinations across the globe. Bes sure, that if you’re purchasing a winter tour with our agency, then the air tickets you’ll be offered are gonna be just as good and affordable!</p>
                  </div>
                  <div class="text-center text-sm-left offset-top-15 offset-md-top-30"><a class="btn btn-default" href="deals.html">Buy Tickets</a></div>
                </div>
              </div>
            </div>
            <div class="range range-xs-center range-sm-left offset-top-0">
              <div class="cell-xs-10 cell-sm-6 section-image-aside section-image-aside-right text-left">
                <div class="section-image-aside-img veil reveal-sm-block" style="background-image: url(wt_61187/images/pages/hotels.jpg); background-position: center center;"></div>
                <div class="section-image-aside-body offset-top-60 offset-sm-top-0 section-sm-90 section-md-111 inset-sm-right-30 inset-lg-right-90">
                  <h2 class="text-bold text-center text-sm-left">Hotel Bookings</h2>
                  <hr class="divider hr-sm-left-0 bg-primary">
                  <div class="offset-top-30 offset-md-top-60">
                    <p>Every trip includes a hotel to stay at. We are good at picking a selection of the best local hotels for you, having an experience of more than 10 years in doing so. Be sure that whatever your country of destination will be, the hotel you’ll be staying at will be awesome!</p>
                  </div>
                  <div class="text-center text-sm-left offset-top-15 offset-md-top-30"><a class="btn btn-default" href="deals.html">Book Now</a></div>
                </div>
              </div>
            </div>
            <div class="range range-xs-center range-sm-right offset-top-0">
              <div class="cell-xs-10 cell-sm-6 section-image-aside section-image-aside-left text-left">
                <div class="section-image-aside-img veil reveal-sm-block" style="background-image: url(wt_61187/images/pages/visa.jpg); background-position: center center;"></div>
                <div class="section-image-aside-body offset-top-60 offset-sm-top-0 section-sm-top-90 section-sm-bottom-90 section-md-top-111 section-md-bottom-162 inset-sm-left-50 inset-lg-left-100">
                  <h2 class="text-bold text-center text-sm-left">Visa</h2>
                  <hr class="divider hr-sm-left-0 bg-primary">
                  <div class="offset-top-30 offset-md-top-60">
                    <p>We know that when it comes to choosing a location for your next holiday, the sheer variety of options that are available can puzzle anyone. This is why our travel agents are dedicated to helping you choose the best winter trip destination for your requirements!</p>
                  </div>
                  <div class="text-center text-sm-left offset-top-15 offset-md-top-30"><a class="btn btn-default" href="deals.html">Apply Now</a></div>
                </div>
              </div>
            </div>
            <div class="range range-xs-center range-sm-left offset-top-0">
              <div class="cell-xs-10 cell-sm-6 section-image-aside section-image-aside-right text-left">
                <div class="section-image-aside-img veil reveal-sm-block" style="background-image: url(wt_61187/images/pages/hajj-umrah.jpg); background-position: center center;"></div>
                <div class="section-image-aside-body offset-top-60 offset-sm-top-0 section-sm-90 section-md-111 inset-sm-right-30 inset-lg-right-90">
                  <h2 class="text-bold text-center text-sm-left">Hajj/Umrah</h2>
                  <hr class="divider hr-sm-left-0 bg-primary">
                  <div class="offset-top-30 offset-md-top-60">
                    <p>While we have a number of pre-selected winter trip destinations on our website, we can always customize any of these tours, tailoring it to your liking... So whether you’ll travel to Switzerland or Nepal - we will make that happen easily!</p>
                  </div>
                  <div class="text-center text-sm-left offset-top-15 offset-md-top-30"><a class="btn btn-default" href="deals.html">Book Now</a></div>
                </div>
              </div>
            </div>
            <div class="range range-xs-center range-sm-right offset-top-0">
              <div class="cell-xs-10 cell-sm-6 section-image-aside section-image-aside-left text-left">
                <div class="section-image-aside-img veil reveal-sm-block" style="background-image: url(wt_61187/images/pages/int-tour.jpg); background-position: center center;"></div>
                <div class="section-image-aside-body offset-top-60 offset-sm-top-0 section-sm-top-90 section-sm-bottom-90 section-md-top-111 section-md-bottom-162 inset-sm-left-50 inset-lg-left-100">
                  <h2 class="text-bold text-center text-sm-left">International Tour</h2>
                  <hr class="divider hr-sm-left-0 bg-primary">
                  <div class="offset-top-30 offset-md-top-60">
                    <p>We know that when it comes to choosing a location for your next holiday, the sheer variety of options that are available can puzzle anyone. This is why our travel agents are dedicated to helping you choose the best winter trip destination for your requirements!</p>
                  </div>
                  <div class="text-center text-sm-left offset-top-15 offset-md-top-30"><a class="btn btn-default" href="single-tour.html">Book Now</a></div>
                </div>
              </div>
            </div>
            <div class="range range-xs-center range-sm-left offset-top-0">
              <div class="cell-xs-10 cell-sm-6 section-image-aside section-image-aside-right text-left">
                <div class="section-image-aside-img veil reveal-sm-block" style="background-image: url(wt_61187/images/pages/domestic-tour.jpg); background-position: center center;"></div>
                <div class="section-image-aside-body offset-top-60 offset-sm-top-0 section-sm-90 section-md-111 inset-sm-right-30 inset-lg-right-90">
                  <h2 class="text-bold text-center text-sm-left">Domestic Tour</h2>
                  <hr class="divider hr-sm-left-0 bg-primary">
                  <div class="offset-top-30 offset-md-top-60">
                    <p>Every trip includes a hotel to stay at. We are good at picking a selection of the best local hotels for you, having an experience of more than 10 years in doing so. Be sure that whatever your country of destination will be, the hotel you’ll be staying at will be awesome!</p>
                  </div>
                  <div class="text-center text-sm-left offset-top-15 offset-md-top-30"><a class="btn btn-default" href="domestic-tour.html">Book Now</a></div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <!-- Page Footer-->
      <!-- Footer Minimal Dark-->
      <?php include "foot.php"; ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- PhotoSwipe Gallery-->
    <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="pswp__bg"></div>
      <div class="pswp__scroll-wrap">
        <div class="pswp__container">
          <div class="pswp__item"></div>
          <div class="pswp__item"></div>
          <div class="pswp__item"></div>
        </div>
        <div class="pswp__ui pswp__ui--hidden">
          <div class="pswp__top-bar">
            <div class="pswp__counter"></div>
            <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
            <button class="pswp__button pswp__button--share" title="Share"></button>
            <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>
            <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
            <div class="pswp__preloader">
              <div class="pswp__preloader__icn">
                <div class="pswp__preloader__cut">
                  <div class="pswp__preloader__donut"></div>
                </div>
              </div>
            </div>
          </div>
          <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
            <div class="pswp__share-tooltip"></div>
          </div>
          <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button>
          <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button>
          <div class="pswp__caption">
            <div class="pswp__caption__center"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- Java script-->
    <script src="wt_61187/js/core.min.js"></script>
    <script src="wt_61187/js/script.js"></script>
  </body><!-- Google Tag Manager --><noscript><iframe src="http://www.googletagmanager.com/ns.html?id=GTM-P9FT69"height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-P9FT69');</script><!-- End Google Tag Manager -->

<!-- Mirrored from livedemo00.template-help.com/wt_61187/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 26 Aug 2019 12:19:17 GMT -->
</html>